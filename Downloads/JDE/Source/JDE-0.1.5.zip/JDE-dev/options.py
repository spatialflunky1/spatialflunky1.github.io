## Contains all default settings that are changeable

fontsize = 10
defaultfont = "Consolas"
windowsize = "1020x725"
icon = "jde.ico"
aboutbanner = "JDEbanner.png"
version = "Version 0.1.5"