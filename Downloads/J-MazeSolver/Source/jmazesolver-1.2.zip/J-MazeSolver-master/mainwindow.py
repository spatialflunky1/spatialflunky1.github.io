from tkinter import *
import time
class Window(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        self.default_speed = 10
        self.draw()
    def close_window(self):
        self.master.destroy()
    def draw(self):
        self.master.title("Choose Maze Size")
        self.pack(fill=BOTH)
    def settitle(self, title):
        self.master.title("JDE" + ":" + title)
