# J-MazeSolver
A Tkinter GUI for maze solving

## Version:
v1.0

## Dependencies:
#### Python 3
#### Tk/Tkinter (python library)

## Note:
Make sure you are running python 3 with:
```
python --version
```
